using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{ 
    //Client
    public GameObject target;

   
    // Update is called once per frame
    void Update()
    {
        
       
        if (Input.GetKeyDown(KeyCode.W))
        {
           MoveCommands moveup = new MoveCommands( transform,Vector2.up,transform.localScale);
            moveup.Exceute();
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            MoveCommands movedown = new MoveCommands(transform, Vector2.down,transform.localScale);
            movedown.Exceute();
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            MoveCommands moveleft = new MoveCommands(transform, Vector2.left, transform.localScale); 
            moveleft.Exceute();
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            MoveCommands moveRight = new MoveCommands(transform, Vector2.right, transform.localScale);
            moveRight.Exceute();
        }
        if (Input.GetKeyDown(KeyCode.R))
        {
            //CommandManager.instance.undoLastCommand();
        }
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction);

            if (hit.collider != null)
            {
                string objectName = hit.collider.gameObject.name;
               
               if (objectName == "Undo")
                {
                    CommandManager.instance.UndoLastCommand();
                }
              else if(objectName == "Increase")
                {
                    Debug.Log(objectName);
                    target.transform.localScale += new Vector3(0.1f, 0.1f, 0.1f);
                    MoveCommands scale = new MoveCommands(transform, Vector2.zero, transform.localScale);
                    scale.Exceute();
                }
               else if (objectName == "Decrease")
                {
                    target.transform.localScale -= new Vector3(0.1f, 0.1f, 0.1f);
                }
               else if ((objectName == "Redo"))
                {
                    CommandManager.instance.RedoLastCommand();
                }

            }
        }

    }
}
